<div class="panel listdiv2" style="margin-top:0 !important;padding-left:0 !important;padding-right:0 !important;margin-top:0;">
       
    <table style="background-color:#f4e9f7 !important;margin-top:0;"  class="table-striped table-border table-panel">
       
        <tr>
            <td class="mintd" style="padding:1px 1px;"><strong>Collections</strong></td>
             
          </tr>
            <tr>
                <td class="mintd" style="padding:1px 1px;">Today:</td>
                <td class="mintd" style="padding:1px 1px;" id="tdbalanceid_{{$savings->id}}"></td>
              </tr>

              <tr>
                <td class="mintd" style="padding:1px 1px;">This Week:</td>
                <td class="mintd" style="padding:1px 1px;" id="tdbalanceid_{{$savings->id}}"></td>
              </tr>

              <tr>
                <td class="mintd" style="padding:1px 1px;">This Month:</td>
                <td class="mintd" style="padding:1px 1px;" id="tdbalanceid_{{$savings->id}}"></td>
              </tr>


        
      </table>
</div>