<style>

    #showotheraccountno{
        display:none;
    }
    .customercodebtn{
        width:98%;
        margin-left:1%;
        margin-right:1%;

    }



    .insetshadow {
        margin:5px 20px;
        padding:10px 10px;
        border-radius:5px 5px 5px 5px;
   
}

    #tdetailstable{
        width:99% !important;
    }
    .tableFixHead {
        overflow: auto;
        height: 100px;
    }

    .tableFixHead thead th {
        position: sticky;
        top: 0;
        z-index: 1;
    }

    /* Just common table stuff. Really. */
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th,
    td {
        padding: 8px 16px;
    }

    th {
        background: #eee;
    }

    .account_name {
        color: #666666;
        text-align: left !important;
        font-weight: bold;
        font-family: verdana;
    }

    .table-panel td {
        font-size: 1em !important;
        color: rgb(65, 6, 65);
        font-family: Verdana, Geneva, Tahoma, sans-serif;
    }

    .accordion img {
        width: 65px;
        height: 65px;
    }

    table td[class='mintd'] {
        padding: 5px 25px !important;
    }

    .listdiv {
        width:97% !important;
        height: auto;
    }

    .listdiv .listdiv .image {
        width: 25%;
        height: 70px;

        background-color: yellow;
    }

    .listdiv .listdiv img {
        width: 70px;

    }

    .listdiv .listdiv .text {
        width: 75%;
        height: 70px;
        background-color: green;
    }

    .listdiv .listdiv .text a,
    .listdiv .listdiv .text span {
        float: left;
        color: purple;
    }


    .listdiv2 {
        height: auto !important;
        height: 600px;
        padding-left:0;padding-right:0;
    }

    .listdiv2 .listdiv2 .image {
        width: 25%;
        height: auto;

    }

    .listdiv2 .listdiv2 img {
        width: 70px;
        height: 70px;
    }

    .listdiv2 .listdiv2 .text {
        width: 75%;
        height: 70px;
        background-color: green;
    }

    .listdiv2 .listdiv2 .text a,
    .listdiv2 .listdiv2 .text span {
        float: left;
        color: purple;
    }

    label{
        text-transform: capitalize !important;
    }
</style>
