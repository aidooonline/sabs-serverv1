@php
    $users=\Auth::user();
    $profile=asset(Storage::url('upload/profile/'));
@endphp

 


 
