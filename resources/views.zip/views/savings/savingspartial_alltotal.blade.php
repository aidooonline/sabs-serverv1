 

<div class="listdiv2" style="margin-top:0 !important;padding-left:0 !important;padding-right:0 !important;margin-top:0;">
       
    <table style="background-color:#f4e9f7 !important;margin-top:20px;"  class="table-striped table-border table-panel rounded">
       
        <tr>
            <td class="mintd" style="padding:1px 1px;"><strong>Total Collections</strong></td>
             
          </tr>
            <tr>
                <td class="mintd" style="padding:1px 1px;">Today:</td>
                <td class="mintd" style="padding:1px 1px;" id="todaytotal">{{$todaytotal}}</td>
              </tr>

              <tr>
                <td class="mintd" style="padding:1px 1px;">This Week:</td>
                <td class="mintd" style="padding:1px 1px;" id="thisweektotal">{{$thisweektotal}}</td>
              </tr>

              <tr>
                <td class="mintd" style="padding:1px 1px;">This Month:</td>
                <td class="mintd" style="padding:1px 1px;" id="thismonthtotal">{{$thismonthtotal}}</td>
              </tr>


        
      </table>
</div>
 